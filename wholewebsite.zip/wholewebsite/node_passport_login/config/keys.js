dbPassword = 'mongodb+srv://sabry:TEoCuknxr7IDHvg7@cluster0.2ilot.mongodb.net/gradProject';

module.exports = {
    mongoURI: dbPassword
};
