const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');


const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const GridFsStorage = require('multer-gridfs-storage');
const Grid = require('gridfs-stream');
const methodOverride = require('method-override');






const app = express();

// Passport Config
require('./config/passport')(passport);

// DB Config
const db = require('./config/keys').mongoURI;

// Connect to MongoDB
mongoose
  .connect(
    db,
    { useNewUrlParser: true ,useUnifiedTopology: true}
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

// EJS
app.use(expressLayouts);
app.set('view engine', 'ejs');

//static files
app.use(express.static('public'));

// Express body parser
app.use(express.urlencoded({ extended: true }));

// Express session
app.use(
  session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
  })
);

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Connect flash
app.use(flash());

// Global variables
app.use(function(req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  next();
});


app.get('/landing', (req, res) => {res.render('index.ejs');});
app.get('/about', (req, res) => {res.render('about.ejs');});
app.get(`/tour`, (req, res) => {res.render('tour.ejs');});
app.get('/contact',(req, res) => {res.render('contact.ejs');});
app.get('/aboutus',(req, res) => {res.render('aboutus.ejs');});

app.get('/addpicture',(req, res) => {

res.render('addpicture.ejs');


  


async function storeImage() {
  try {

    client.db('gradProject'); // Replace 'yourDatabaseName' with your actual database name
    const bucket = new GridFSBucket(db);

    //replace with image path
    const readableStream = fs.createReadStream('path/to/your/image.jpg'); // Replace with the actual path to your image file
    const filename = 'image.jpg'; // Replace with the desired filename for the image

    const uploadStream = bucket.openUploadStream(filename);
    const id = uploadStream.id;

    readableStream.pipe(uploadStream);

    uploadStream.on('finish', () => {
      console.log(`Image stored in MongoDB with ID: ${id}`);
    });

    uploadStream.on('error', (err) => {
      console.error('Error storing image:', err);
    });
  } catch (err) {
    console.error('Error storing image:', err);
  }
}

storeImage();

async function storeImage() {
  try {
    const db = client.db('yourDatabaseName'); // Replace 'yourDatabaseName' with your actual database name

    const bucket = new GridFSBucket(db);

    const readableStream = fs.createReadStream('path/to/your/image.jpg'); // Replace with the actual path to your image file
    const filename = 'image.jpg'; // Replace with the desired filename for the image

    const uploadStream = bucket.openUploadStream(filename);
    const id = uploadStream.id;

    readableStream.pipe(uploadStream);

    uploadStream.on('finish', () => {
      console.log(`Image stored in MongoDB with ID: ${id}`);
    });

    uploadStream.on('error', (err) => {
      console.error('Error storing image:', err);
    });
  } catch (err) {
    console.error('Error storing image:', err);
  }
}


  res.send("done")
  //add picture to database code 


});
// Routes
app.use('/', require('./routes/index.js'));
app.use('/users', require('./routes/users.js'));

const PORT = process.env.PORT || 5013;

app.listen(PORT, console.log(`Server running on  ${PORT}`));
